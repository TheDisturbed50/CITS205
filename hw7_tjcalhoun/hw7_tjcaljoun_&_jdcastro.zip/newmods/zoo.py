'''
Zoo Hours of Operation
Created for Homework #7, CITS 205 Spring 2016.
'''
def hours():
    print('''
          DAS ZOO:

    Monday     9am to 5pm
    Tuesday    9am to 5pm
    Wednesday  9am to 5pm
    Thursday   9am to 5pm
    Friday     9am to 5pm
    Saturday     CLOSED
    Sunday       CLOSED
    '''.center(80))